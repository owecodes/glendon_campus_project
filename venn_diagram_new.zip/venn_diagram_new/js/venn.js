var count = 0;
function allowDrop(ev){
ev.preventDefault();
}

function drag(ev)
{
ev.dataTransfer.setData("Text",ev.target.id);
}

function drop(ev){

ev.preventDefault();
var thetag = ev.target.nodeName;
var theanswer = ev.target.className;
var data=ev.dataTransfer.getData("Text");
  if(thetag == "TERM"){
    null;
  }
  else{
    ev.target.appendChild(document.getElementById(data));

  }

}



function restartbutton(){
  setTimeout(function() {
    //$('#win').hide();
    $('#replay').css( "display", "block");
  },2000);
}


function submit(){
  alert("All Done!");
  //window.location.reload();
}
